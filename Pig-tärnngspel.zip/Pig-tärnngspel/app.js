// Declare Variables
var scores, roundScore, activePlayer, gamePlaying, lastDice;

// Initialize Variables (Array, Integer)
init();

// Function to display the correct dice image based on the rolled number
function displayDice(dice) {
    var diceDom = document.querySelector('.dice');
    diceDom.style.display = 'block'; // Ensure the dice image is visible
    diceDom.src = 'images/dice-' + dice + '.png'; // Update the image source dynamically
}

// Roll Dice button implementation
document.querySelector('.btn-roll').addEventListener('click', function () {
    // Dealing with the game's state
    if (gamePlaying) {
        // Random Number generator
        var dice = Math.floor(Math.random() * 6) + 1;

        // Display the dice image
        displayDice(dice);

        // Update the round score IF the rolled number was NOT a 1
        if (dice === 6 && lastDice === 6) {
            // Player loses their entire score
            scores[activePlayer] = 0;
            document.querySelector('#score-' + activePlayer).textContent = '0';
            nextPlayer();
        } else if (dice !== 1) {
            // Player adds score to their round score
            roundScore += dice;
            document.querySelector('#current-' + activePlayer).textContent = roundScore;
        } else {
            // Player rolled a 1, move to next player
            nextPlayer();
        }

        // Store the last dice roll to check for double 6s
        lastDice = dice;
    }
});

// Hold Button implementation
document.querySelector('.btn-hold').addEventListener('click', function () {
    if (gamePlaying) {
        // Add CURRENT score to GLOBAL score
        scores[activePlayer] += roundScore;

        // Update the UI
        document.querySelector('#score-' + activePlayer).textContent = scores[activePlayer];

        // Get the winning score from the input field or use 100 as default
        var input = document.querySelector('.final-score').value;
        var winningScore = input ? input : 100;

        // Check if the player wins the game
        if (scores[activePlayer] >= winningScore) {
            document.querySelector('#name-' + activePlayer).textContent = 'Winner!';
            document.querySelector('.dice').style.display = 'none'; // Hide the dice image after winning
            document.querySelector('.player-' + activePlayer + '-panel').classList.add('winner');
            document.querySelector('.player-' + activePlayer + '-panel').classList.remove('active');
            document.querySelector('.player-' + activePlayer + '-panel').style.backgroundImage = "url(winwin.png)";
            gamePlaying = false;
        } else {
            // Next player
            nextPlayer();
        }
    }
});

function nextPlayer() {
    // Switch to the next player
    activePlayer === 0 ? activePlayer = 1 : activePlayer = 0;
    roundScore = 0;

    // Reset round score display
    document.getElementById('current-0').textContent = 0;
    document.getElementById('current-1').textContent = 0;

    // Toggle active class for players
    document.querySelector('.player-0-panel').classList.toggle('active');
    document.querySelector('.player-1-panel').classList.toggle('active');

    // Hide the dice image when switching players
    document.querySelector('.dice').style.display = 'none';
}

// New Game
document.querySelector('.btn-new').addEventListener('click', init);

// DRY function to initialize the game
function init() {
    // Initialize Variables (Array, Integer)
    scores = [0, 0];
    roundScore = 0;
    activePlayer = 0;

    // Dealing with the game's state
    gamePlaying = true;

    // Hide the dice image at the start of the game
    document.querySelector('.dice').style.display = 'none';

    // Reset UI for scores and player names
    document.getElementById('score-0').textContent = '0';
    document.getElementById('score-1').textContent = '0';
    document.getElementById('current-0').textContent = '0';
    document.getElementById('current-1').textContent = '0';
    document.getElementById('name-0').textContent = 'Player 1';
    document.getElementById('name-1').textContent = 'Player 2';

    // Remove winner class and reset backgrounds
    document.querySelector('.player-0-panel').classList.remove('winner');
    document.querySelector('.player-1-panel').classList.remove('winner');
    document.querySelector('.player-0-panel').classList.remove('active');
    document.querySelector('.player-1-panel').classList.remove('active');
    document.querySelector('.player-0-panel').style.backgroundImage = "none";
    document.querySelector('.player-1-panel').style.backgroundImage = "none";
    document.querySelector('.player-0-panel').classList.add('active');
};

// Clicking for instructions
document.querySelector(".instructions").addEventListener("click", function () {
    document.querySelector(".modal").classList.add("show");
    document.querySelector(".close").addEventListener("click", function () {
        document.querySelector(".modal").classList.remove("show");
    });
});
